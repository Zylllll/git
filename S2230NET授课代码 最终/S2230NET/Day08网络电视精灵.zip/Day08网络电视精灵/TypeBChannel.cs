﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;


namespace Day08网络电视精灵
{
    /// <summary>
    /// TypeB类型节目单解析

    /// </summary>
    public class TypeBChannel : ChannelBase
    {
        public override void Fetch()
        {

        }
    }
}
