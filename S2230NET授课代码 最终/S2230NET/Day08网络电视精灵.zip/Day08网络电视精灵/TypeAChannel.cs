﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;


namespace Day08网络电视精灵
{
    /// <summary>
    /// TypeA类型节目单解析

    /// </summary>
    public class TypeAChannel : ChannelBase
    {

        public override void Fetch()
        {
           
        }
    }
}
